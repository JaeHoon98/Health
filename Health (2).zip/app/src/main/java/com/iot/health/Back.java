package com.iot.health;

import android.app.ActivityManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.net.Uri;
import android.widget.ImageButton;

public class Back extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.back);
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                switch (v.getId()) {
                    case R.id.button:
                        intent.setData(Uri.parse("https://www.youtube.com/watch?v=5jZ940J6w6Y"));
                        startActivity(intent);
                        break;
                }
            }
        });
        ImageButton button3 = (ImageButton) findViewById(R.id.button3);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                finish();
            }
        });
    }
}
